<!DOCTYPE html>
<html>

<head>
<title>Vehicle Mnagement System</title>
<link href="css/custom.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet"  type="text/css" href="css/bootstrap.min.css"/>
<script rel="stylesheet" src="js/main.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="page-wrap">
<div class="header">
<div class="logo">
<a href="new.html"><img src="images/logo1.png" alt=""/></a>
<div class="navigation">
	<nav class="navbar navbar-inverse navbar-fixed">
	  <div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			</div>

			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			  <ul class="nav navbar-nav">
			  <li class="active"><a href="new.html">Home <span class="sr-only">(current)</span></a></li>
			  <li><a href="#">About us</a></li>
				<li><a href="#">Contacts</a></li>
			  </ul>
			  
			</div>
		</div><!-- /.navbar-collapse -->
	</nav>
</div>
</div>
<div class="container-fluid">
	<div class="page-header text-center">
	<h1 class="text-uppercase"> Car Information & Details<h1>
	<h3> <i></i></h3>
	</div>



	<div class="row">
		<div class="col-md-4">
			<p><h3><bold><i>Lamborgini Huracan</i></bold></h3><p><br>
			<div class="thumbnail">
			<img src="images/23.jpg" alt="...">
			</div>
		</div>
		<div class="col-md-4">
			<p><h4><i>Model: Lamborghini Huracan Mansory Torofeo<i></h4></p>
			<p> Category:  
			<p> Price: $650,000 </p>
			<p> Color: Light-Blue
			<p> Status:   </P>
			<p> Top Speed: 370 kph/ 221 mph</p>
			<p>Registration-year: 2016 </p>
			<p>Gear: </p>
			<p> Doors: </p>
			<p>Seats: <p>
			<p> Tanks: </p>
		</div>

	</div>
</div>

</body>
</html>